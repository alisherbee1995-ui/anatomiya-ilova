# Anatomiya atamalari — Android

GitHub Actions har bir `main` yangilanishida APK faylini avtomatik yig‘adi.

## APKni olish

1. GitHub omborida **Actions** bo‘limini oching.
2. **APK yaratish** ishini tanlang.
3. Yashil belgi chiqqach, ish natijasini oching.
4. Pastdagi **Anatomiya-atamalari-APK** faylini yuklab oling.
5. ZIP ichidan `app-debug.apk` faylini telefonga o‘rnating.
