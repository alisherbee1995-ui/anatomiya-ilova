MYTESTING MOBILE — NATIVE ANDROID V1

TEXNOLOGIYA
- Kotlin
- Jetpack Compose
- Supabase REST/RPC backend
- Android minSdk 26, target/compile SDK 37

ASOSIY IMKONIYATLAR
USTOZ:
- Email/parol bilan kirish va ro'yxatdan o'tish
- Fan yaratish
- .xlsx va .csv savollar bazasini import qilish
- Importdan oldin savollarni tekshirish, xato qatorlarni ko'rsatish
- Takroriy savollarni aniqlash
- Nazorat yaratish: savol soni, vaqt, baho chegaralari, natijani ko'rsatish
- 6 xonali kod
- Talabalarni ko'rish, bittalab yoki hammaga ruxsat berish
- Bloklangan talabaga xavfsiz yangi urinish berish
- Natijalarni Excel (.xlsx) ga eksport qilish

TALABA:
- Akkauntsiz kirish: familiya, ism, guruh, yo'nalish, 6 xonali kod
- Har urinish uchun serverdan maxfiy token
- Random savollar va random javob variantlari
- Har javob serverga darhol saqlanadi
- Aloqa uzilsa javob vaqtincha telefonda pending sifatida saqlanib, keyin qayta yuboriladi
- Vaqt server bo'yicha nazorat qilinadi va 10 soniyada sinxronlanadi
- FLAG_SECURE: screenshot/screen recording Android darajasida cheklanadi
- Test vaqtida Back tugmasi bloklanadi
- Home/Recent Apps, background, split-screen va Picture-in-Picture holatlari qoidabuzarlik sifatida aniqlanadi
- Lock Task chaqiriladi; oddiy shaxsiy telefonda Android to'liq kiosk kafolatlamaydi

SERVER
- Supabase loyiha: Mytesting-Mobile
- Public publishable key BuildConfig ichida, secret/service-role kalit yo'q
- To'g'ri javob kaliti talaba qurilmasiga yuborilmaydi
- Join rate-limit serverda mavjud
- Eski student RPC endpointlari olib tashlangan

SINOV
- Androidga bog'liq bo'lmagan Kotlin XLSX parseri haqiqiy Gistologiya 200 savolli Excel faylida tekshirildi: 200 savol, 0 xato.
- Natija XLSX writer openpyxl bilan ochib tekshirildi.
- Ushbu muhitda Android SDK/Gradle o'rnatilmagan, shuning uchun bu yerda APK build qilinmadi.

ANDROID STUDIO'DA OCHISH
1. Android Studio'ni oching.
2. Open tugmasi bilan MyTesting_Android_Native_V1 papkasini tanlang.
3. Gradle sync tugashini kuting.
4. Agar compileSdk 37 hali o'rnatilmagan bo'lsa, Android Studio SDK Manager orqali o'rnatadi yoki app/build.gradle.kts ichidagi compileSdk/targetSdk ni sizdagi SDKga moslang.
5. Run orqali telefonda sinang.
6. APK uchun: Build > Build APK(s).

MUHIM XAVFSIZLIK IZOH
Oddiy shaxsiy Android qurilmada hech bir oddiy ilova boshqa ilovalarni mutlaq 100% bloklay olmaydi. To'liq kiosk/lock-task uchun universitet boshqaradigan Device Owner / Managed Device rejimi kerak. Ushbu loyiha oddiy telefonlarda mavjud bo'lgan kuchli himoyalarni qo'llaydi: FLAG_SECURE, lifecycle/background detection, Back block, split-screen/PiP detection, server-side attempt invalidation.


V2 YANGILIKLARI — OBUNA VA QAYTA TOPSHIRISH
- Ustoz uchun 30 kunlik obuna holati serverda saqlanadi.
- To'lov tasdiqlanganda 30 kun avtomatik qo'shish uchun server helper tayyor.
- Obuna faol bo'lmasa yangi nazorat yaratish server va ilova darajasida bloklanadi.
- Joriy ishlab chiqish akkauntlariga testni to'xtatmaslik uchun bir martalik 30 kunlik trial berilgan.
- Talaba bloklansa yoki o'tish foizidan past natija olsa, "Qayta topshirish so'rovi" yubora oladi.
- Ustoz so'rovni tasdiqlamaguncha yangi urinish boshlanmaydi.
- Oldingi urinish o'chirilmaydi: attempt_history jadvalida savol/javob va qoidabuzarlik snapshoti saqlanadi.
- Yangi urinish random savollar bilan ochiladi va attempt_no oshadi.
- Haqiqiy pul qabul qilish uchun Click/Payme/Uzum kabi provayderning merchant/webhook rekvizitlari keyingi ulanish bosqichida kerak.
