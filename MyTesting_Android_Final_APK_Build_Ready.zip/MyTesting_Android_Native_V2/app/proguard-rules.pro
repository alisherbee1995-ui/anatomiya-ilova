# MyTesting uses reflection-free JSON parsing (org.json), so no special keeps are required.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
