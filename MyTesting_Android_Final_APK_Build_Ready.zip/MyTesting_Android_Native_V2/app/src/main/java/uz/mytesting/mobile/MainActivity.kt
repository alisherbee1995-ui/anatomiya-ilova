package uz.mytesting.mobile

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import uz.mytesting.mobile.ui.MyTestingApp
import uz.mytesting.mobile.ui.MyTestingViewModel
import uz.mytesting.mobile.util.ExamGuard

class MainActivity : ComponentActivity() {
    private val vm: MyTestingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyTestingApp(vm) }
    }

    override fun onUserLeaveHint() {
        if (ExamGuard.active) {
            ExamGuard.trigger("Test vaqtida Home yoki Recent Apps orqali ilovadan chiqishga urinish aniqlandi.")
        }
        super.onUserLeaveHint()
    }

    override fun onStop() {
        if (ExamGuard.active && !isChangingConfigurations) {
            ExamGuard.trigger("Test ilovasi fon rejimiga o‘tdi yoki boshqa ilova ochildi.")
        }
        super.onStop()
    }

    override fun onMultiWindowModeChanged(isInMultiWindowMode: Boolean, newConfig: Configuration) {
        super.onMultiWindowModeChanged(isInMultiWindowMode, newConfig)
        if (isInMultiWindowMode && ExamGuard.active) {
            ExamGuard.trigger("Split-screen (ikki oynali) rejimga o‘tish aniqlandi.")
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode && ExamGuard.active) {
            ExamGuard.trigger("Picture-in-Picture rejimiga o‘tish aniqlandi.")
        }
    }
}
