package uz.mytesting.mobile.data

import android.content.Context
import uz.mytesting.mobile.model.AuthSession
import uz.mytesting.mobile.model.StudentIdentity
import uz.mytesting.mobile.model.StudentSession

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("mytesting_secure_state", Context.MODE_PRIVATE)

    fun saveTeacher(session: AuthSession) {
        prefs.edit()
            .putString("teacher_access", session.accessToken)
            .putString("teacher_refresh", session.refreshToken)
            .putString("teacher_user_id", session.userId)
            .putString("teacher_email", session.email)
            .apply()
    }

    fun loadTeacher(): AuthSession? {
        val access = prefs.getString("teacher_access", null) ?: return null
        val refresh = prefs.getString("teacher_refresh", null) ?: return null
        val uid = prefs.getString("teacher_user_id", null) ?: return null
        val email = prefs.getString("teacher_email", null) ?: ""
        return AuthSession(access, refresh, uid, email)
    }

    fun clearTeacher() {
        prefs.edit()
            .remove("teacher_access")
            .remove("teacher_refresh")
            .remove("teacher_user_id")
            .remove("teacher_email")
            .apply()
    }

    fun saveStudent(session: StudentSession) {
        prefs.edit()
            .putString("student_attempt", session.attemptId)
            .putString("student_token", session.token)
            .putString("student_surname", session.identity.surname)
            .putString("student_first", session.identity.firstName)
            .putString("student_group", session.identity.groupName)
            .putString("student_direction", session.identity.direction)
            .apply()
    }

    fun loadStudent(): StudentSession? {
        val attempt = prefs.getString("student_attempt", null) ?: return null
        val token = prefs.getString("student_token", null) ?: return null
        return StudentSession(
            attemptId = attempt,
            token = token,
            identity = StudentIdentity(
                surname = prefs.getString("student_surname", "") ?: "",
                firstName = prefs.getString("student_first", "") ?: "",
                groupName = prefs.getString("student_group", "") ?: "",
                direction = prefs.getString("student_direction", "") ?: ""
            )
        )
    }

    fun clearStudent() {
        prefs.edit()
            .remove("student_attempt")
            .remove("student_token")
            .remove("student_surname")
            .remove("student_first")
            .remove("student_group")
            .remove("student_direction")
            .apply()
    }
}
