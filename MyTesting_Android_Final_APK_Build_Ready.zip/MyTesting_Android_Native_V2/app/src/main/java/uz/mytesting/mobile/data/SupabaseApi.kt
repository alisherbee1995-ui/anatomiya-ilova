package uz.mytesting.mobile.data

import org.json.JSONArray
import org.json.JSONObject
import uz.mytesting.mobile.BuildConfig
import uz.mytesting.mobile.model.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

class ApiException(message: String, val statusCode: Int = 0) : Exception(message)

private data class HttpResponse(
    val code: Int,
    val body: String,
    val headers: Map<String, List<String>>
)

class SupabaseApi(private val store: SessionStore) {
    private val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val apiKey = BuildConfig.SUPABASE_PUBLISHABLE_KEY

    private fun request(
        path: String,
        method: String = "GET",
        body: String? = null,
        bearer: String? = null,
        prefer: String? = null,
        extraHeaders: Map<String, String> = emptyMap()
    ): HttpResponse {
        val connection = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15_000
            readTimeout = 25_000
            setRequestProperty("apikey", apiKey)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
            if (!prefer.isNullOrBlank()) setRequestProperty("Prefer", prefer)
            extraHeaders.forEach { (k, v) -> setRequestProperty(k, v) }
            if (body != null) doOutput = true
        }

        if (body != null) {
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseBody = if (stream != null) {
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        } else ""
        val headers = connection.headerFields.filterKeys { it != null }
        connection.disconnect()
        return HttpResponse(code, responseBody, headers)
    }

    private fun errorMessage(response: HttpResponse): String {
        if (response.body.isBlank()) return "Server xatosi (${response.code})"
        return try {
            val o = JSONObject(response.body)
            o.optString("message").ifBlank { o.optString("msg") }.ifBlank { response.body }
        } catch (_: Exception) {
            response.body
        }
    }

    private fun requireOk(response: HttpResponse): HttpResponse {
        if (response.code !in 200..299) throw ApiException(errorMessage(response), response.code)
        return response
    }

    fun signUp(email: String, password: String, fullName: String): String {
        val payload = JSONObject()
            .put("email", email)
            .put("password", password)
            .put("data", JSONObject().put("full_name", fullName))
        val response = requireOk(request("/auth/v1/signup", "POST", payload.toString()))
        val json = JSONObject(response.body)
        val access = json.optString("access_token")
        return if (access.isNotBlank()) {
            saveAuth(json, email)
            "Akkaunt yaratildi va tizimga kirildi."
        } else {
            "Akkaunt yaratildi. Emailga kelgan tasdiqlash havolasini bosing, keyin kiring."
        }
    }

    fun login(email: String, password: String): AuthSession {
        val payload = JSONObject().put("email", email).put("password", password)
        val response = requireOk(request("/auth/v1/token?grant_type=password", "POST", payload.toString()))
        return saveAuth(JSONObject(response.body), email)
    }

    private fun saveAuth(json: JSONObject, fallbackEmail: String): AuthSession {
        val access = json.getString("access_token")
        val refresh = json.getString("refresh_token")
        val user = json.getJSONObject("user")
        val session = AuthSession(
            accessToken = access,
            refreshToken = refresh,
            userId = user.getString("id"),
            email = user.optString("email", fallbackEmail)
        )
        store.saveTeacher(session)
        return session
    }

    fun refreshTeacherSession(): AuthSession {
        val old = store.loadTeacher() ?: throw ApiException("Ustoz sessiyasi topilmadi")
        val payload = JSONObject().put("refresh_token", old.refreshToken)
        val response = requireOk(request("/auth/v1/token?grant_type=refresh_token", "POST", payload.toString()))
        return saveAuth(JSONObject(response.body), old.email)
    }

    private fun authedRequest(
        path: String,
        method: String = "GET",
        body: String? = null,
        prefer: String? = null,
        extraHeaders: Map<String, String> = emptyMap()
    ): HttpResponse {
        var session = store.loadTeacher() ?: throw ApiException("Ustoz akkauntiga kiring")
        var response = request(path, method, body, session.accessToken, prefer, extraHeaders)
        if (response.code == 401) {
            session = refreshTeacherSession()
            response = request(path, method, body, session.accessToken, prefer, extraHeaders)
        }
        return requireOk(response)
    }

    fun listSubjects(): List<SubjectItem> {
        val response = authedRequest("/rest/v1/subjects?select=id,name&order=created_at.asc")
        val array = JSONArray(response.body)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(SubjectItem(o.getString("id"), o.getString("name")))
            }
        }
    }

    fun createSubject(name: String): SubjectItem {
        val session = store.loadTeacher() ?: throw ApiException("Ustoz akkauntiga kiring")
        val body = JSONObject().put("teacher_id", session.userId).put("name", name)
        val response = authedRequest(
            "/rest/v1/subjects",
            "POST",
            body.toString(),
            prefer = "return=representation"
        )
        val o = JSONArray(response.body).getJSONObject(0)
        return SubjectItem(o.getString("id"), o.getString("name"))
    }

    fun questionCount(subjectId: String): Int {
        val response = authedRequest(
            "/rest/v1/questions?select=id&subject_id=eq.$subjectId&limit=1",
            extraHeaders = mapOf("Prefer" to "count=exact")
        )
        val contentRange = response.headers.entries
            .firstOrNull { it.key.equals("Content-Range", true) }
            ?.value?.firstOrNull()
            ?: return if (response.body == "[]") 0 else JSONArray(response.body).length()
        return contentRange.substringAfterLast('/').toIntOrNull() ?: 0
    }

    fun insertQuestions(subjectId: String, questions: List<ImportQuestion>) {
        questions.chunked(200).forEach { batch ->
            val array = JSONArray()
            batch.forEach { q ->
                array.put(
                    JSONObject()
                        .put("subject_id", subjectId)
                        .put("question_text", q.questionText)
                        .put("options", JSONArray(q.options))
                        .put("correct_index", q.correctIndex)
                )
            }
            authedRequest("/rest/v1/questions", "POST", array.toString(), prefer = "return=minimal")
        }
    }

    fun deleteQuestions(subjectId: String) {
        authedRequest("/rest/v1/questions?subject_id=eq.$subjectId", "DELETE", prefer = "return=minimal")
    }

    fun createExam(
        subjectId: String,
        title: String,
        questionCount: Int,
        durationMinutes: Int,
        grade5Min: Int,
        grade4Min: Int,
        grade3Min: Int,
        showResult: Boolean,
        instructions: String
    ): ExamItem {
        val session = store.loadTeacher() ?: throw ApiException("Ustoz akkauntiga kiring")
        // Bir ustoz uchun avvalgi ochiq nazoratlarni yopamiz.
        authedRequest(
            "/rest/v1/exams?teacher_id=eq.${session.userId}&is_open=eq.true",
            "PATCH",
            JSONObject().put("is_open", false).toString(),
            prefer = "return=minimal"
        )

        var lastError: Exception? = null
        repeat(6) {
            val code = (100000..999999).random().toString()
            val body = JSONObject()
                .put("teacher_id", session.userId)
                .put("subject_id", subjectId)
                .put("title", title)
                .put("access_code", code)
                .put("question_count", questionCount)
                .put("duration_minutes", durationMinutes)
                .put("grade5_min", grade5Min)
                .put("grade4_min", grade4Min)
                .put("grade3_min", grade3Min)
                .put("show_result", showResult)
                .put("instructions", instructions)
                .put("is_open", true)
            try {
                val response = authedRequest(
                    "/rest/v1/exams",
                    "POST",
                    body.toString(),
                    prefer = "return=representation"
                )
                return parseExam(JSONArray(response.body).getJSONObject(0))
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: ApiException("Nazorat kodini yaratib bo‘lmadi")
    }

    fun latestExam(openOnly: Boolean = false): ExamItem? {
        val session = store.loadTeacher() ?: return null
        val openFilter = if (openOnly) "&is_open=eq.true" else ""
        val response = authedRequest(
            "/rest/v1/exams?select=*&teacher_id=eq.${session.userId}$openFilter&order=created_at.desc&limit=1"
        )
        val array = JSONArray(response.body)
        return if (array.length() == 0) null else parseExam(array.getJSONObject(0))
    }

    fun closeExam(examId: String) {
        authedRequest(
            "/rest/v1/exams?id=eq.$examId",
            "PATCH",
            JSONObject().put("is_open", false).toString(),
            prefer = "return=minimal"
        )
    }

    private fun parseExam(o: JSONObject) = ExamItem(
        id = o.getString("id"),
        subjectId = o.getString("subject_id"),
        teacherId = o.getString("teacher_id"),
        title = o.getString("title"),
        accessCode = o.getString("access_code"),
        questionCount = o.optInt("question_count", 30),
        durationMinutes = o.optInt("duration_minutes", 30),
        grade5Min = o.optInt("grade5_min", 86),
        grade4Min = o.optInt("grade4_min", 71),
        grade3Min = o.optInt("grade3_min", 55),
        showResult = o.optBoolean("show_result", true),
        isOpen = o.optBoolean("is_open", false),
        instructions = o.optString("instructions").takeIf { it.isNotBlank() && it != "null" }
    )

    fun listAttempts(examId: String): List<AttemptItem> {
        val response = authedRequest(
            "/rest/v1/attempts?select=*&exam_id=eq.$examId&order=created_at.asc"
        )
        val array = JSONArray(response.body)
        return buildList {
            for (i in 0 until array.length()) add(parseAttempt(array.getJSONObject(i)))
        }
    }

    private fun parseAttempt(o: JSONObject) = AttemptItem(
        id = o.getString("id"),
        examId = o.getString("exam_id"),
        surname = o.optString("surname"),
        firstName = o.optString("first_name"),
        groupName = o.optString("group_name"),
        direction = o.optString("direction"),
        status = o.optString("status"),
        score = if (o.isNull("score")) null else o.optInt("score"),
        total = if (o.isNull("total")) null else o.optInt("total"),
        percent = if (o.isNull("percent")) null else o.optDouble("percent"),
        grade = if (o.isNull("grade")) null else o.optInt("grade"),
        violationReason = if (o.isNull("violation_reason")) null else o.optString("violation_reason"),
        attemptNo = o.optInt("attempt_no", 1),
        attemptMode = o.optString("attempt_mode", "primary"),
        retakeRequestedAt = if (o.isNull("retake_requested_at")) null else o.optString("retake_requested_at"),
        retakeAuthorizedAt = if (o.isNull("retake_authorized_at")) null else o.optString("retake_authorized_at")
    )

    fun teacherApprove(attemptId: String) {
        teacherRpc("teacher_approve_attempt", JSONObject().put("p_attempt_id", attemptId))
    }

    fun teacherApproveAll(examId: String) {
        teacherRpc("teacher_approve_all", JSONObject().put("p_exam_id", examId))
    }

    fun teacherAuthorizeRetake(attemptId: String) {
        teacherRpc("teacher_authorize_retake", JSONObject().put("p_attempt_id", attemptId))
    }

    fun teacherReset(attemptId: String) {
        teacherAuthorizeRetake(attemptId)
    }

    fun teacherSubscriptionStatus(): SubscriptionStatus {
        val o = teacherRpc("teacher_subscription_status", JSONObject())
        return SubscriptionStatus(
            active = o.optBoolean("active", false),
            status = o.optString("status", "inactive"),
            startedAt = if (o.isNull("started_at")) null else o.optString("started_at"),
            endsAt = if (o.isNull("ends_at")) null else o.optString("ends_at"),
            daysRemaining = o.optInt("days_remaining", 0)
        )
    }

    private fun teacherRpc(name: String, payload: JSONObject): JSONObject {
        val response = authedRequest(
            "/rest/v1/rpc/$name",
            "POST",
            payload.toString()
        )
        return JSONObject(response.body)
    }

    fun studentJoin(
        code: String,
        identity: StudentIdentity,
        deviceFingerprint: String
    ): StudentJoinResult {
        val payload = JSONObject()
            .put("p_code", code)
            .put("p_surname", identity.surname)
            .put("p_first_name", identity.firstName)
            .put("p_group_name", identity.groupName)
            .put("p_direction", identity.direction)
            .put("p_device_fingerprint", deviceFingerprint)
        val o = studentRpcObject("student_v4_request_join", payload)
        return StudentJoinResult(
            attemptId = o.getString("attempt_id"),
            token = o.getString("student_token"),
            status = o.getString("status"),
            title = o.optString("title"),
            subjectName = o.optString("subject_name"),
            durationMinutes = o.optInt("duration_minutes", 30),
            instructions = o.optString("instructions").takeIf { it.isNotBlank() && it != "null" }
        )
    }

    fun studentState(attemptId: String, token: String): StudentState {
        val o = studentRpcObject(
            "student_v4_attempt_state",
            JSONObject().put("p_attempt_id", attemptId).put("p_token", token)
        )
        return parseStudentState(o)
    }

    fun studentStart(attemptId: String, token: String): StudentState {
        val o = studentRpcObject(
            "student_v4_start_attempt",
            JSONObject().put("p_attempt_id", attemptId).put("p_token", token)
        )
        return parseStudentState(o)
    }

    fun studentQuestions(attemptId: String, token: String): List<ExamQuestion> {
        val payload = JSONObject().put("p_attempt_id", attemptId).put("p_token", token)
        val response = requireOk(request("/rest/v1/rpc/student_v4_get_questions", "POST", payload.toString()))
        val array = JSONArray(response.body)
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val opts = o.getJSONArray("options")
                val options = buildList { for (j in 0 until opts.length()) add(opts.getString(j)) }
                add(
                    ExamQuestion(
                        attemptQuestionId = o.getString("attempt_question_id"),
                        displayOrder = o.optInt("display_order", i + 1),
                        questionText = o.getString("question_text"),
                        options = options
                    )
                )
            }
        }
    }

    fun studentSaveAnswer(attemptId: String, token: String, attemptQuestionId: String, selectedIndex: Int) {
        studentRpcObject(
            "student_v4_save_answer",
            JSONObject()
                .put("p_attempt_id", attemptId)
                .put("p_token", token)
                .put("p_attempt_question_id", attemptQuestionId)
                .put("p_selected_index", selectedIndex)
        )
    }

    fun studentFinish(attemptId: String, token: String): StudentState {
        val o = studentRpcObject(
            "student_v4_finish_attempt",
            JSONObject().put("p_attempt_id", attemptId).put("p_token", token)
        )
        return parseStudentState(o)
    }

    fun studentBlock(attemptId: String, token: String, reason: String): StudentState {
        val o = studentRpcObject(
            "student_v4_block_attempt",
            JSONObject().put("p_attempt_id", attemptId).put("p_token", token).put("p_reason", reason)
        )
        return parseStudentState(o)
    }

    fun studentRequestRetake(attemptId: String, token: String): StudentState {
        val o = studentRpcObject(
            "student_request_retake",
            JSONObject().put("p_attempt_id", attemptId).put("p_token", token)
        )
        return parseStudentState(o)
    }

    private fun studentRpcObject(name: String, payload: JSONObject): JSONObject {
        val response = requireOk(request("/rest/v1/rpc/$name", "POST", payload.toString()))
        return JSONObject(response.body)
    }

    private fun parseStudentState(o: JSONObject) = StudentState(
        attemptId = o.getString("attempt_id"),
        status = o.getString("status"),
        score = if (o.isNull("score")) null else o.optInt("score"),
        total = if (o.isNull("total")) null else o.optInt("total"),
        percent = if (o.isNull("percent")) null else o.optDouble("percent"),
        grade = if (o.isNull("grade")) null else o.optInt("grade"),
        violationReason = if (o.isNull("violation_reason")) null else o.optString("violation_reason"),
        title = o.optString("title"),
        subjectName = o.optString("subject_name"),
        durationMinutes = o.optInt("duration_minutes", 30),
        secondsRemaining = if (o.isNull("seconds_remaining")) null else o.optInt("seconds_remaining"),
        showResult = o.optBoolean("show_result", true),
        instructions = o.optString("instructions").takeIf { it.isNotBlank() && it != "null" },
        attemptNo = o.optInt("attempt_no", 1),
        attemptMode = o.optString("attempt_mode", "primary"),
        retakeAvailable = o.optBoolean("retake_available", false),
        retakeRequested = o.optBoolean("retake_requested", false)
    )
}
