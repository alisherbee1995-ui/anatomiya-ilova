package uz.mytesting.mobile.model

data class AuthSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String
)

data class SubjectItem(
    val id: String,
    val name: String
)

data class ExamItem(
    val id: String,
    val subjectId: String,
    val teacherId: String,
    val title: String,
    val accessCode: String,
    val questionCount: Int,
    val durationMinutes: Int,
    val grade5Min: Int,
    val grade4Min: Int,
    val grade3Min: Int,
    val showResult: Boolean,
    val isOpen: Boolean,
    val instructions: String?
)

data class AttemptItem(
    val id: String,
    val examId: String,
    val surname: String,
    val firstName: String,
    val groupName: String,
    val direction: String,
    val status: String,
    val score: Int?,
    val total: Int?,
    val percent: Double?,
    val grade: Int?,
    val violationReason: String?,
    val attemptNo: Int = 1,
    val attemptMode: String = "primary",
    val retakeRequestedAt: String? = null,
    val retakeAuthorizedAt: String? = null
)

data class ImportQuestion(
    val questionText: String,
    val options: List<String>,
    val correctIndex: Int
)

data class ImportError(
    val row: Int,
    val message: String
)

data class ImportPreview(
    val questions: List<ImportQuestion>,
    val errors: List<ImportError>,
    val fileName: String
)

data class StudentJoinResult(
    val attemptId: String,
    val token: String,
    val status: String,
    val title: String,
    val subjectName: String,
    val durationMinutes: Int,
    val instructions: String?
)

data class StudentState(
    val attemptId: String,
    val status: String,
    val score: Int?,
    val total: Int?,
    val percent: Double?,
    val grade: Int?,
    val violationReason: String?,
    val title: String,
    val subjectName: String,
    val durationMinutes: Int,
    val secondsRemaining: Int?,
    val showResult: Boolean,
    val instructions: String?,
    val attemptNo: Int = 1,
    val attemptMode: String = "primary",
    val retakeAvailable: Boolean = false,
    val retakeRequested: Boolean = false
)

data class SubscriptionStatus(
    val active: Boolean,
    val status: String,
    val startedAt: String?,
    val endsAt: String?,
    val daysRemaining: Int
)

data class ExamQuestion(
    val attemptQuestionId: String,
    val displayOrder: Int,
    val questionText: String,
    val options: List<String>
)

data class StudentIdentity(
    val surname: String,
    val firstName: String,
    val groupName: String,
    val direction: String
)

data class StudentSession(
    val attemptId: String,
    val token: String,
    val identity: StudentIdentity
)
