package uz.mytesting.mobile.ui

import android.app.Activity
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import uz.mytesting.mobile.model.*
import uz.mytesting.mobile.util.ExamGuard

private val Blue = Color(0xFF315EFB)
private val Bg = Color(0xFFF3F6FB)
private val Green = Color(0xFF168A52)
private val Red = Color(0xFFC33A3A)
private val Amber = Color(0xFFA96A00)

@Composable
fun MyTestingApp(vm: MyTestingViewModel) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            background = Bg,
            surface = Color.White,
            error = Red
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize()) {
                Header(vm)
                if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                vm.message?.let { msg ->
                    MessageCard(msg) { vm.clearMessage() }
                }
                Box(Modifier.fillMaxSize()) {
                    when (vm.mode) {
                        MyTestingViewModel.Mode.HOME -> HomeScreen(vm)
                        MyTestingViewModel.Mode.TEACHER -> TeacherScreen(vm)
                        MyTestingViewModel.Mode.STUDENT -> StudentScreen(vm)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(vm: MyTestingViewModel) {
    Surface(color = Color.White, shadowElevation = 2.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("MyTesting Mobile", fontWeight = FontWeight.Black, fontSize = 21.sp)
                Text("Native Android • xavfsiz nazorat", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
            }
            if (vm.mode != MyTestingViewModel.Mode.HOME && vm.studentPhase != MyTestingViewModel.StudentPhase.EXAM) {
                TextButton(onClick = vm::goHome) { Text("Bosh sahifa") }
            }
        }
    }
}

@Composable
private fun MessageCard(text: String, onDismiss: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F4FF))
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, Modifier.weight(1f))
            IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Yopish") }
        }
    }
}

@Composable
private fun HomeScreen(vm: MyTestingViewModel) {
    Column(
        Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Rejimni tanlang", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(22.dp))
        Button(onClick = vm::openTeacher, modifier = Modifier.fillMaxWidth().height(58.dp)) {
            Icon(Icons.Default.School, null); Spacer(Modifier.width(8.dp)); Text("USTOZ")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = vm::openStudent, modifier = Modifier.fillMaxWidth().height(58.dp)) {
            Icon(Icons.Default.Person, null); Spacer(Modifier.width(8.dp)); Text("TALABA")
        }
    }
}

@Composable
private fun TeacherScreen(vm: MyTestingViewModel) {
    if (vm.teacherSession == null) TeacherAuthScreen(vm) else TeacherDashboard(vm)
}

@Composable
private fun TeacherAuthScreen(vm: MyTestingViewModel) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SectionCard {
            Text("Ustoz akkaunti", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Parol") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(fullName, { fullName = it }, label = { Text("F.I.Sh. (ro‘yxatdan o‘tishda)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.login(email, password) }, modifier = Modifier.weight(1f), enabled = !vm.busy) { Text("Kirish") }
                OutlinedButton(onClick = { vm.signUp(email, password, fullName) }, modifier = Modifier.weight(1f), enabled = !vm.busy) { Text("Ro‘yxatdan o‘tish") }
            }
            Spacer(Modifier.height(10.dp))
            Text("Yangi akkauntda Supabase email tasdiqlashni talab qilishi mumkin.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TeacherDashboard(vm: MyTestingViewModel) {
    Column(Modifier.fillMaxSize()) {
        vm.subscription?.let { sub ->
            val bg = if (sub.active) Color(0xFFE8F7EF) else Color(0xFFFFE8E8)
            val fg = if (sub.active) Green else Red
            Surface(color = bg, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (sub.active) "Obuna faol" else "Obuna faol emas", fontWeight = FontWeight.Bold, color = fg)
                        Text(if (sub.active) "${sub.daysRemaining} kun qoldi" else "Yangi nazorat ochish bloklangan", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("30 kunlik", fontWeight = FontWeight.Bold, color = fg)
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TabButton("Savollar", vm.teacherTab == MyTestingViewModel.TeacherTab.BANK) { vm.teacherTab = MyTestingViewModel.TeacherTab.BANK }
            TabButton("Nazorat", vm.teacherTab == MyTestingViewModel.TeacherTab.EXAM) { vm.teacherTab = MyTestingViewModel.TeacherTab.EXAM; vm.refreshTeacher() }
            TabButton("Natijalar", vm.teacherTab == MyTestingViewModel.TeacherTab.RESULTS) { vm.teacherTab = MyTestingViewModel.TeacherTab.RESULTS; vm.loadResults() }
        }
        when (vm.teacherTab) {
            MyTestingViewModel.TeacherTab.BANK -> QuestionBankScreen(vm)
            MyTestingViewModel.TeacherTab.EXAM -> TeacherExamScreen(vm)
            MyTestingViewModel.TeacherTab.RESULTS -> ResultsScreen(vm)
        }
    }
}

@Composable
private fun RowScope.TabButton(text: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick, modifier = Modifier.weight(1f)) { Text(text) }
    else OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(text) }
}

@Composable
private fun QuestionBankScreen(vm: MyTestingViewModel) {
    var subjectName by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::previewImport)
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionCard {
                Text("Fan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(subjectName, { subjectName = it }, label = { Text("Yangi fan nomi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.createSubject(subjectName); subjectName = "" }, enabled = !vm.busy) { Text("Fan yaratish") }
                Spacer(Modifier.height(12.dp))
                SubjectSelector(vm.subjects, vm.selectedSubjectId) { vm.selectSubject(it) }
                Spacer(Modifier.height(8.dp))
                Text("Bazadagi savollar: ${vm.selectedQuestionCount} ta", fontWeight = FontWeight.Bold)
            }
        }
        item {
            SectionCard {
                Text("Savollar bazasini yuklash", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Excel (.xlsx) yoki CSV. Ustunlar: Savol | A | B | C | D | To‘g‘ri javob", color = Color.Gray)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { fileLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv", "text/comma-separated-values")) }) {
                    Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(6.dp)); Text("Fayl tanlash va tekshirish")
                }
                vm.importPreview?.let { preview ->
                    Spacer(Modifier.height(12.dp))
                    Text(preview.fileName, fontWeight = FontWeight.Bold)
                    Text("To‘g‘ri: ${preview.questions.size} ta • Xato: ${preview.errors.size} ta")
                    preview.questions.take(5).forEachIndexed { i, q ->
                        Text("${i + 1}. ${q.questionText}", modifier = Modifier.padding(top = 5.dp), style = MaterialTheme.typography.bodySmall)
                    }
                    preview.errors.take(6).forEach { e ->
                        Text("Qator ${e.row}: ${e.message}", color = Red, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = vm::importQuestions, enabled = preview.questions.isNotEmpty() && !vm.busy) { Text("${preview.questions.size} ta savolni bazaga yuklash") }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = { confirmDelete = true }, enabled = vm.selectedQuestionCount > 0 && !vm.busy, colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) {
                    Text("Tanlangan fan savollarini o‘chirish")
                }
                if (confirmDelete) ConfirmDialog("Barcha savollar o‘chirilsinmi?", "Bu amalni ortga qaytarib bo‘lmaydi.", onConfirm = { confirmDelete = false; vm.deleteAllQuestions() }, onDismiss = { confirmDelete = false })
            }
        }
        item {
            OutlinedButton(onClick = vm::logout, modifier = Modifier.fillMaxWidth()) { Text("Ustoz akkauntidan chiqish") }
        }
    }
}

@Composable
private fun SubjectSelector(subjects: List<SubjectItem>, selectedId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = subjects.firstOrNull { it.id == selectedId }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), enabled = subjects.isNotEmpty()) {
            Text(selected?.name ?: if (subjects.isEmpty()) "Fan yaratilmagan" else "Fan tanlang", Modifier.weight(1f))
            Icon(Icons.Default.ArrowDropDown, null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            subjects.forEach { s ->
                DropdownMenuItem(text = { Text(s.name) }, onClick = { expanded = false; onSelect(s.id) })
            }
        }
    }
}

@Composable
private fun TeacherExamScreen(vm: MyTestingViewModel) {
    val openExam = vm.currentExam
    if (openExam != null) {
        OpenExamDashboard(vm, openExam)
    } else {
        NewExamForm(vm)
    }
}

@Composable
private fun NewExamForm(vm: MyTestingViewModel) {
    var subjectId by remember(vm.subjects, vm.selectedSubjectId) { mutableStateOf(vm.selectedSubjectId ?: vm.subjects.firstOrNull()?.id) }
    var title by remember { mutableStateOf("1-oraliq nazorat") }
    var count by remember { mutableStateOf("30") }
    var minutes by remember { mutableStateOf("30") }
    var g5 by remember { mutableStateOf("86") }
    var g4 by remember { mutableStateOf("71") }
    var g3 by remember { mutableStateOf("55") }
    var showResult by remember { mutableStateOf(true) }
    var instructions by remember { mutableStateOf("Test davomida boshqa ilovaga o‘tish, ekran tasvirini olish yoki test oynasini tark etish taqiqlanadi.") }

    Column(Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState())) {
        SectionCard {
            Text("Yangi nazorat", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            SubjectSelector(vm.subjects, subjectId) { subjectId = it }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(title, { title = it }, label = { Text("Nazorat nomi") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            NumberField("Har talabaga savol soni", count) { count = it }
            Spacer(Modifier.height(8.dp))
            NumberField("Vaqt (daqiqa)", minutes) { minutes = it }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.weight(1f)) { NumberField("5 baho %", g5) { g5 = it } }
                Box(Modifier.weight(1f)) { NumberField("4 baho %", g4) { g4 = it } }
                Box(Modifier.weight(1f)) { NumberField("3 baho %", g3) { g3 = it } }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(showResult, { showResult = it })
                Spacer(Modifier.width(8.dp)); Text("Natijani talabaga ko‘rsatish")
            }
            OutlinedTextField(instructions, { instructions = it }, label = { Text("Ko‘rsatma") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Spacer(Modifier.height(12.dp))
            if (vm.subscription?.active != true) {
                WarningBox("Obuna faol bo‘lmasa yangi nazorat ochilmaydi. To‘lov provayderi ulanganidan keyin to‘lov tasdiqlansa 30 kun avtomatik faollik beriladi.")
                Spacer(Modifier.height(8.dp))
            }
            Button(
                onClick = {
                    val sid = subjectId ?: return@Button
                    vm.createExam(sid, title, count.toIntOrNull() ?: 0, minutes.toIntOrNull() ?: 0, g5.toIntOrNull() ?: 86, g4.toIntOrNull() ?: 71, g3.toIntOrNull() ?: 55, showResult, instructions)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = subjectId != null && !vm.busy && vm.subscription?.active == true
            ) { Text("Nazorat yaratish va ochish") }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.all(Char::isDigit)) onChange(it) },
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true
    )
}

@Composable
private fun OpenExamDashboard(vm: MyTestingViewModel, exam: ExamItem) {
    var confirmClose by remember { mutableStateOf(false) }
    LaunchedEffect(exam.id) {
        while (vm.currentExam?.id == exam.id) {
            vm.refreshAttempts(silent = true)
            delay(2200)
        }
    }
    if (confirmClose) ConfirmDialog("Nazorat yopilsinmi?", "Yangi talabalar kod bilan kira olmaydi. Hozir ishlayotgan urinishlar serverdagi holatida qoladi.", onConfirm = { confirmClose = false; vm.closeExam() }, onDismiss = { confirmClose = false })
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            SectionCard {
                val subject = vm.subjects.firstOrNull { it.id == exam.subjectId }?.name.orEmpty()
                Text("$subject — ${exam.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${exam.questionCount} savol • ${exam.durationMinutes} daqiqa", color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Surface(color = Color(0xFFF0F4FF), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(exam.accessCode, modifier = Modifier.padding(14.dp), fontSize = 36.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                }
                Spacer(Modifier.height(10.dp))
                val pending = vm.attempts.count { it.status == "pending" || it.status == "approved" }
                val active = vm.attempts.count { it.status == "active" }
                val done = vm.attempts.count { it.status == "done" }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Kpi("$pending", "Kutilmoqda", Modifier.weight(1f))
                    Kpi("$active", "Ishlamoqda", Modifier.weight(1f))
                    Kpi("$done", "Tugatdi", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::approveAll, modifier = Modifier.weight(1f), enabled = pending > 0) { Text("Barchasiga ruxsat") }
                    OutlinedButton(onClick = { confirmClose = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Text("Nazoratni yopish") }
                }
            }
        }
        if (vm.attempts.isEmpty()) item { Text("Hali talaba ulanmagan.", color = Color.Gray) }
        items(vm.attempts, key = { it.id }) { attempt ->
            AttemptCard(attempt, onApprove = { vm.approveAttempt(attempt.id) }, onRetake = { vm.authorizeRetake(attempt.id) })
        }
    }
}

@Composable
private fun AttemptCard(a: AttemptItem, onApprove: () -> Unit, onRetake: () -> Unit) {
    var confirmRetake by remember { mutableStateOf(false) }
    if (confirmRetake) ConfirmDialog(
        "Qayta topshirishga ruxsat berilsinmi?",
        "Oldingi urinish tarixda saqlanadi. Talabaga yangi random savollar bilan ${a.attemptNo + 1}-urinish ochiladi.",
        onConfirm = { confirmRetake = false; onRetake() },
        onDismiss = { confirmRetake = false }
    )
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${a.surname} ${a.firstName}", fontWeight = FontWeight.Bold)
                    Text("${a.groupName} • ${a.direction}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                StatusBadge(a.status)
            }
            Text("${a.attemptNo}-urinish • ${if (a.attemptMode == "retake") "Qayta topshirish" else "Asosiy"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            if (a.percent != null) Text("${a.score}/${a.total} • ${a.percent}% • Baho ${a.grade}", fontWeight = FontWeight.Bold)
            a.violationReason?.let { Text(it, color = Red, style = MaterialTheme.typography.bodySmall) }
            if (a.retakeRequestedAt != null) {
                Text("Qayta topshirish so‘rovi yuborilgan", color = Amber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
            }
            if (a.status == "pending") {
                Spacer(Modifier.height(8.dp)); Button(onClick = onApprove) { Text("Ruxsat berish") }
            }
            if ((a.status == "blocked" || a.status == "done") && a.retakeRequestedAt != null) {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { confirmRetake = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFF1D5), contentColor = Amber)
                ) { Text("Qayta topshirishga ruxsat") }
            }
        }
    }
}

@Composable
private fun ResultsScreen(vm: MyTestingViewModel) {
    val createDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri -> uri?.let(vm::exportResults) }

    LaunchedEffect(Unit) { vm.loadResults() }
    val done = vm.attempts.filter { it.status == "done" }
    val avg = if (done.isEmpty()) 0.0 else done.mapNotNull { it.percent }.average()
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            SectionCard {
                Text("Natijalar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                vm.resultExam?.let { Text(it.title, color = Color.Gray) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Kpi(vm.attempts.size.toString(), "Jami", Modifier.weight(1f))
                    Kpi(done.size.toString(), "Tugatdi", Modifier.weight(1f))
                    Kpi(String.format("%.1f%%", avg), "O‘rtacha", Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val name = (vm.resultExam?.title ?: "nazorat").replace(Regex("[^A-Za-z0-9_-]"), "_")
                        createDocument.launch("MyTesting_${name}_natijalar.xlsx")
                    },
                    enabled = vm.attempts.isNotEmpty()
                ) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Excel yuklab olish")
                }
            }
        }
        itemsIndexed(vm.attempts) { index, a ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(11.dp)) {
                    Text("${index + 1}. ${a.surname} ${a.firstName}", fontWeight = FontWeight.Bold)
                    Text("${a.groupName} • ${statusText(a.status)} • ${a.percent ?: "—"}% • Baho ${a.grade ?: "—"}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun StudentScreen(vm: MyTestingViewModel) {
    when (vm.studentPhase) {
        MyTestingViewModel.StudentPhase.JOIN -> StudentJoinScreen(vm)
        MyTestingViewModel.StudentPhase.WAIT -> StudentWaitScreen(vm)
        MyTestingViewModel.StudentPhase.EXAM -> StudentExamScreen(vm)
        MyTestingViewModel.StudentPhase.BLOCKED -> StudentBlockedScreen(vm)
        MyTestingViewModel.StudentPhase.RESULT -> StudentResultScreen(vm)
    }
}

@Composable
private fun StudentJoinScreen(vm: MyTestingViewModel) {
    var surname by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        SectionCard {
            Text("Nazoratga kirish", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(surname, { surname = it }, label = { Text("Familiya") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(firstName, { firstName = it }, label = { Text("Ism") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(group, { group = it }, label = { Text("Guruh") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(direction, { direction = it }, label = { Text("Yo‘nalish") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(7.dp))
            OutlinedTextField(code, { if (it.length <= 6 && it.all(Char::isDigit)) code = it }, label = { Text("6 xonali nazorat kodi") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Spacer(Modifier.height(12.dp))
            WarningBox("Test boshlanganidan keyin boshqa ilova, Home/Recent tugmasi, split-screen yoki test oynasini tark etish urinishni bloklaydi. Ekran tasviri va yozib olish Android tomonidan cheklanadi.")
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { vm.joinStudent(code, StudentIdentity(surname.trim(), firstName.trim(), group.trim(), direction.trim())) },
                modifier = Modifier.fillMaxWidth(), enabled = !vm.busy
            ) { Text("Ustozdan ruxsat so‘rash") }
        }
    }
}

@Composable
private fun StudentWaitScreen(vm: MyTestingViewModel) {
    LaunchedEffect(vm.studentSession?.attemptId) {
        while (vm.studentPhase == MyTestingViewModel.StudentPhase.WAIT) {
            vm.checkStudentState(silent = true)
            delay(1500)
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
        SectionCard {
            Text("Ustoz ruxsati kutilmoqda", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            vm.studentState?.let { Text("${it.subjectName} — ${it.title}", color = Color.Gray) }
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text("Ustoz sizni ro‘yxatda ko‘radi. Ruxsat berilgach test avtomatik boshlanadi.")
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { vm.checkStudentState(silent = false) }) { Text("Holatni tekshirish") }
        }
    }
}

@Composable
private fun StudentExamScreen(vm: MyTestingViewModel) {
    var confirmFinish by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val activity = context as Activity
    BackHandler(enabled = true) { /* Test vaqtida Back ishlamaydi. */ }

    DisposableEffect(Unit) {
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        try { activity.startLockTask() } catch (_: Exception) { }
        ExamGuard.activate()
        onDispose {
            try { activity.stopLockTask() } catch (_: Exception) { }
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    LaunchedEffect(Unit) {
        var syncCounter = 0
        while (vm.studentPhase == MyTestingViewModel.StudentPhase.EXAM) {
            delay(1000)
            vm.tickSecond()
            syncCounter++
            if (syncCounter >= 10) {
                syncCounter = 0
                vm.syncStudentTimer()
            }
        }
    }

    if (confirmFinish) ConfirmDialog("Test yakunlansinmi?", "Yakunlangandan keyin javoblarni o‘zgartirib bo‘lmaydi.", onConfirm = { confirmFinish = false; vm.finishStudentExam() }, onDismiss = { confirmFinish = false })
    val total = vm.questions.size
    val answered = vm.answers.size
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Surface(color = Bg) {
                Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${vm.studentState?.subjectName.orEmpty()} — ${vm.studentState?.title.orEmpty()}", fontWeight = FontWeight.Bold)
                                vm.studentSession?.identity?.let { Text("${it.surname} ${it.firstName} • ${it.groupName}", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
                            }
                            Text(formatTime(vm.remainingSeconds), fontSize = 24.sp, fontWeight = FontWeight.Black, color = if (vm.remainingSeconds < 60) Red else Blue)
                        }
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { if (total == 0) 0f else answered.toFloat() / total }, modifier = Modifier.fillMaxWidth())
                        Text("Javob berildi: $answered / $total", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item {
            vm.studentState?.instructions?.let { WarningBox(it) }
        }
        itemsIndexed(vm.questions, key = { _, q -> q.attemptQuestionId }) { index, q ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp)) {
                    Text("${index + 1}. ${q.questionText}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(7.dp))
                    q.options.forEachIndexed { optionIndex, option ->
                        Surface(
                            onClick = { vm.saveAnswer(q, optionIndex) },
                            color = if (vm.answers[q.attemptQuestionId] == optionIndex) Color(0xFFF0F4FF) else Color.White,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (vm.answers[q.attemptQuestionId] == optionIndex) Blue else Color(0xFFDCE2EC)),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Row(Modifier.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = vm.answers[q.attemptQuestionId] == optionIndex, onClick = { vm.saveAnswer(q, optionIndex) })
                                Text(option)
                            }
                        }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(6.dp))
            Button(onClick = { confirmFinish = true }, modifier = Modifier.fillMaxWidth(), enabled = !vm.busy) { Text("TESTNI YAKUNLASH") }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun StudentBlockedScreen(vm: MyTestingViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
        SectionCard {
            Icon(Icons.Default.Block, null, tint = Red, modifier = Modifier.size(48.dp))
            Text("Nazorat bloklandi", style = MaterialTheme.typography.headlineSmall, color = Red, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text(vm.studentState?.violationReason ?: ExamGuard.violation.value ?: "Test xavfsizlik qoidasi buzildi.")
            Spacer(Modifier.height(12.dp))
            val st = vm.studentState
            if (st?.retakeAvailable == true) {
                Spacer(Modifier.height(8.dp))
                if (st.retakeRequested) {
                    Text("Qayta topshirish so‘rovi ustozga yuborildi.", color = Amber, fontWeight = FontWeight.Bold)
                    LaunchedEffect(st.attemptId, st.retakeRequested) {
                        while (vm.studentPhase == MyTestingViewModel.StudentPhase.BLOCKED && vm.studentState?.retakeRequested == true) {
                            delay(1500)
                            vm.checkStudentState(silent = true)
                        }
                    }
                } else {
                    Button(onClick = vm::requestRetake, enabled = !vm.busy) { Text("QAYTA TOPSHIRISH SO‘ROVI") }
                }
            } else {
                Text("Bu nazorat hozir qayta topshirish uchun ochiq emas.", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { vm.checkStudentState(silent = false) }) { Text("Holatni tekshirish") }
        }
    }
}

@Composable
private fun StudentResultScreen(vm: MyTestingViewModel) {
    val state = vm.studentState
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
        SectionCard {
            Icon(Icons.Default.CheckCircle, null, tint = Green, modifier = Modifier.size(52.dp))
            Text("Nazorat yakunlandi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            if (state?.showResult == true) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Kpi("${state.score ?: 0}/${state.total ?: 0}", "To‘g‘ri", Modifier.weight(1f))
                    Kpi("${state.percent ?: 0}%", "Foiz", Modifier.weight(1f))
                    Kpi("${state.grade ?: 0}", "Baho", Modifier.weight(1f))
                }
            } else Text("Natijani ustoz ko‘radi.")
            Spacer(Modifier.height(14.dp))
            if (state?.retakeAvailable == true) {
                if (state.retakeRequested) {
                    Text("Qayta topshirish so‘rovi ustozga yuborildi.", color = Amber, fontWeight = FontWeight.Bold)
                    LaunchedEffect(state.attemptId, state.retakeRequested) {
                        while (vm.studentPhase == MyTestingViewModel.StudentPhase.RESULT && vm.studentState?.retakeRequested == true) {
                            delay(1500)
                            vm.checkStudentState(silent = true)
                        }
                    }
                } else {
                    Button(onClick = vm::requestRetake, modifier = Modifier.fillMaxWidth(), enabled = !vm.busy) { Text("QAYTA TOPSHIRISH SO‘ROVI") }
                    Spacer(Modifier.height(8.dp))
                }
            }
            OutlinedButton(onClick = vm::leaveStudentSession, modifier = Modifier.fillMaxWidth()) { Text("Yangi nazorat uchun chiqish") }
        }
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
}

@Composable
private fun Kpi(value: String, label: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color(0xFFF8FAFD), shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E6EF))) {
        Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, fontSize = 19.sp)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}

@Composable
private fun StatusBadge(status: String) {
    val (bg, fg) = when (status) {
        "pending" -> Color(0xFFFFF2CF) to Color(0xFF8C6500)
        "approved", "active" -> Color(0xFFE6F6ED) to Green
        "blocked" -> Color(0xFFFEE4E4) to Red
        "done" -> Color(0xFFE8EDFF) to Color(0xFF3855C7)
        else -> Color.LightGray to Color.DarkGray
    }
    Surface(color = bg, shape = RoundedCornerShape(20.dp)) {
        Text(statusText(status), color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
    }
}

@Composable
private fun WarningBox(text: String) {
    Surface(color = Color(0xFFFFF4F4), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = Red)
            Spacer(Modifier.width(7.dp))
            Text(text, style = MaterialTheme.typography.bodySmall)
        }
    }
}


@Composable
private fun ConfirmDialog(title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Tasdiqlash") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Bekor qilish") } }
    )
}

private fun statusText(status: String) = when (status) {
    "pending" -> "KUTILMOQDA"
    "approved" -> "RUXSAT"
    "active" -> "ISHLAMOQDA"
    "blocked" -> "BLOKLANDI"
    "done" -> "TUGATDI"
    else -> status.uppercase()
}

private fun formatTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}
