package uz.mytesting.mobile.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.mytesting.mobile.data.ApiException
import uz.mytesting.mobile.data.SessionStore
import uz.mytesting.mobile.data.SupabaseApi
import uz.mytesting.mobile.model.*
import uz.mytesting.mobile.util.DeviceId
import uz.mytesting.mobile.util.ExamGuard
import uz.mytesting.mobile.util.QuestionFileParser
import uz.mytesting.mobile.util.XlsxResultsWriter

class MyTestingViewModel(app: Application) : AndroidViewModel(app) {
    enum class Mode { HOME, TEACHER, STUDENT }
    enum class TeacherTab { BANK, EXAM, RESULTS }
    enum class StudentPhase { JOIN, WAIT, EXAM, BLOCKED, RESULT }

    private val store = SessionStore(app)
    private val api = SupabaseApi(store)
    private val deviceId = DeviceId.get(app)

    var mode by mutableStateOf(Mode.HOME)
    var teacherTab by mutableStateOf(TeacherTab.BANK)
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    var teacherSession by mutableStateOf(store.loadTeacher())
        private set
    var subjects by mutableStateOf<List<SubjectItem>>(emptyList())
        private set
    var selectedSubjectId by mutableStateOf<String?>(null)
    var selectedQuestionCount by mutableStateOf(0)
        private set
    var importPreview by mutableStateOf<ImportPreview?>(null)
        private set
    var currentExam by mutableStateOf<ExamItem?>(null)
        private set
    var resultExam by mutableStateOf<ExamItem?>(null)
        private set
    var attempts by mutableStateOf<List<AttemptItem>>(emptyList())
        private set
    var subscription by mutableStateOf<SubscriptionStatus?>(null)
        private set

    var studentSession by mutableStateOf(store.loadStudent())
        private set
    var studentState by mutableStateOf<StudentState?>(null)
        private set
    var studentPhase by mutableStateOf(StudentPhase.JOIN)
        private set
    var questions by mutableStateOf<List<ExamQuestion>>(emptyList())
        private set
    var answers by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var remainingSeconds by mutableStateOf(0)
        private set
    private val pendingAnswers = mutableMapOf<String, Pair<ExamQuestion, Int>>()

    init {
        viewModelScope.launch {
            ExamGuard.violation.filterNotNull().collect { reason ->
                blockForViolation(reason)
            }
        }
    }

    fun clearMessage() { message = null }

    fun goHome() {
        if (studentPhase == StudentPhase.EXAM) return
        mode = Mode.HOME
    }

    fun openTeacher() {
        mode = Mode.TEACHER
        if (teacherSession != null) refreshTeacher()
    }

    fun openStudent() {
        mode = Mode.STUDENT
        restoreStudent()
    }

    fun signUp(email: String, password: String, fullName: String) = runBusy {
        val msg = api.signUp(email.trim(), password, fullName.trim().ifBlank { email.substringBefore('@') })
        teacherSession = store.loadTeacher()
        message = msg
        if (teacherSession != null) refreshTeacherInternal()
    }

    fun login(email: String, password: String) = runBusy {
        teacherSession = api.login(email.trim(), password)
        message = "Tizimga muvaffaqiyatli kirdingiz."
        refreshTeacherInternal()
    }

    fun logout() {
        store.clearTeacher()
        teacherSession = null
        subjects = emptyList()
        currentExam = null
        attempts = emptyList()
        teacherTab = TeacherTab.BANK
        message = "Akkauntdan chiqildi."
    }

    fun refreshTeacher() = runBusy { refreshTeacherInternal() }

    private fun refreshTeacherInternal() {
        subjects = api.listSubjects()
        if (selectedSubjectId !in subjects.map { it.id }) selectedSubjectId = subjects.firstOrNull()?.id
        selectedQuestionCount = selectedSubjectId?.let(api::questionCount) ?: 0
        subscription = api.teacherSubscriptionStatus()
        currentExam = api.latestExam(openOnly = true)
        currentExam?.let { attempts = api.listAttempts(it.id) }
    }

    fun createSubject(name: String) = runBusy {
        if (name.isBlank()) throw ApiException("Fan nomini kiriting")
        val created = api.createSubject(name.trim())
        subjects = api.listSubjects()
        selectedSubjectId = created.id
        selectedQuestionCount = 0
        message = "${created.name} fani yaratildi."
    }

    fun selectSubject(id: String) = runBusy {
        selectedSubjectId = id
        selectedQuestionCount = api.questionCount(id)
        importPreview = null
    }

    fun previewImport(uri: Uri) = runBusy {
        val context = getApplication<Application>()
        val fileName = queryFileName(uri) ?: "savollar.xlsx"
        val preview = withContext(Dispatchers.IO) {
            context.contentResolver.openInputStream(uri)?.use { QuestionFileParser.parse(it, fileName) }
                ?: throw ApiException("Faylni ochib bo‘lmadi")
        }
        importPreview = preview
        message = "${preview.questions.size} ta to‘g‘ri savol, ${preview.errors.size} ta xato qator topildi."
    }

    private fun queryFileName(uri: Uri): String? {
        val context = getApplication<Application>()
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun importQuestions() = runBusy {
        val subjectId = selectedSubjectId ?: throw ApiException("Avval fan tanlang")
        val preview = importPreview ?: throw ApiException("Avval faylni tekshiring")
        if (preview.questions.isEmpty()) throw ApiException("Yuklash uchun to‘g‘ri savol yo‘q")
        api.insertQuestions(subjectId, preview.questions)
        selectedQuestionCount = api.questionCount(subjectId)
        importPreview = null
        message = "Savollar bazaga muvaffaqiyatli yuklandi. Jami: $selectedQuestionCount ta."
    }

    fun deleteAllQuestions() = runBusy {
        val subjectId = selectedSubjectId ?: throw ApiException("Fan tanlanmagan")
        api.deleteQuestions(subjectId)
        selectedQuestionCount = 0
        importPreview = null
        message = "Tanlangan fan savollari o‘chirildi."
    }

    fun createExam(
        subjectId: String,
        title: String,
        questionCount: Int,
        minutes: Int,
        grade5: Int,
        grade4: Int,
        grade3: Int,
        showResult: Boolean,
        instructions: String
    ) = runBusy {
        val sub = api.teacherSubscriptionStatus()
        subscription = sub
        if (!sub.active) throw ApiException("Obuna faol emas. Yangi nazorat yaratish uchun 30 kunlik obunani faollashtiring.")
        if (title.isBlank()) throw ApiException("Nazorat nomini kiriting")
        if (questionCount <= 0 || minutes <= 0) throw ApiException("Savol soni va vaqt 0 dan katta bo‘lsin")
        if (!(grade5 > grade4 && grade4 > grade3 && grade3 >= 0)) {
            throw ApiException("Baho chegaralari 5 > 4 > 3 tartibida bo‘lsin")
        }
        val available = api.questionCount(subjectId)
        if (available < questionCount) throw ApiException("Bazadagi savol $available ta, nazorat uchun $questionCount ta kerak")
        currentExam = api.createExam(
            subjectId, title.trim(), questionCount, minutes,
            grade5, grade4, grade3, showResult, instructions.trim()
        )
        attempts = emptyList()
        teacherTab = TeacherTab.EXAM
        message = "Nazorat ochildi. Kod: ${currentExam?.accessCode}"
    }

    fun refreshAttempts(silent: Boolean = true) {
        val exam = currentExam ?: return
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { api.listAttempts(exam.id) }
                attempts = list
            } catch (e: Exception) {
                if (!silent) message = e.message ?: "Yangilashda xato"
            }
        }
    }

    fun approveAttempt(id: String) = runBusy {
        api.teacherApprove(id)
        currentExam?.let { attempts = api.listAttempts(it.id) }
    }

    fun approveAll() = runBusy {
        val exam = currentExam ?: throw ApiException("Ochiq nazorat yo‘q")
        api.teacherApproveAll(exam.id)
        attempts = api.listAttempts(exam.id)
    }

    fun authorizeRetake(id: String) = runBusy {
        api.teacherAuthorizeRetake(id)
        currentExam?.let { attempts = api.listAttempts(it.id) }
        message = "Talabaga qayta topshirishga ruxsat berildi."
    }

    fun resetAttempt(id: String) = authorizeRetake(id)

    fun closeExam() = runBusy {
        val exam = currentExam ?: return@runBusy
        api.closeExam(exam.id)
        resultExam = exam.copy(isOpen = false)
        currentExam = null
        teacherTab = TeacherTab.RESULTS
        loadResultsInternal()
        message = "Nazorat yopildi."
    }

    fun loadResults() = runBusy { loadResultsInternal() }

    private fun loadResultsInternal() {
        val exam = api.latestExam(openOnly = false)
        resultExam = exam
        attempts = exam?.let { api.listAttempts(it.id) } ?: emptyList()
    }

    fun exportResults(uri: Uri) = runBusy {
        if (attempts.isEmpty()) throw ApiException("Eksport qilish uchun natija yo‘q")
        val context = getApplication<Application>()
        withContext(Dispatchers.IO) {
            context.contentResolver.openOutputStream(uri)?.use { XlsxResultsWriter.write(attempts, it) }
                ?: throw ApiException("Faylga yozib bo‘lmadi")
        }
        message = "Natijalar Excel faylga saqlandi."
    }

    fun restoreStudent() {
        val session = store.loadStudent()
        studentSession = session
        if (session == null) {
            studentPhase = StudentPhase.JOIN
            return
        }
        checkStudentState()
    }

    fun joinStudent(code: String, identity: StudentIdentity) = runBusy {
        if (code.length != 6 || code.any { !it.isDigit() }) throw ApiException("6 xonali nazorat kodini kiriting")
        if (identity.surname.isBlank() || identity.firstName.isBlank() || identity.groupName.isBlank() || identity.direction.isBlank()) {
            throw ApiException("Talaba ma’lumotlarini to‘liq kiriting")
        }
        val joined = api.studentJoin(code, identity, deviceId)
        val session = StudentSession(joined.attemptId, joined.token, identity)
        store.saveStudent(session)
        studentSession = session
        studentState = StudentState(
            joined.attemptId, joined.status, null, null, null, null, null,
            joined.title, joined.subjectName, joined.durationMinutes, null, true, joined.instructions
        )
        routeStudent(joined.status)
    }

    fun checkStudentState(silent: Boolean = true) {
        val session = studentSession ?: return
        viewModelScope.launch {
            try {
                val state = withContext(Dispatchers.IO) { api.studentState(session.attemptId, session.token) }
                studentState = state
                if (state.secondsRemaining != null) remainingSeconds = state.secondsRemaining
                when (state.status) {
                    "pending" -> studentPhase = StudentPhase.WAIT
                    "approved" -> startStudentExam()
                    "active" -> {
                        if (questions.isEmpty()) startStudentExam() else {
                            studentPhase = StudentPhase.EXAM
                            ExamGuard.activate()
                        }
                    }
                    "blocked" -> {
                        studentPhase = StudentPhase.BLOCKED
                        ExamGuard.complete()
                    }
                    "done" -> {
                        studentPhase = StudentPhase.RESULT
                        ExamGuard.complete()
                    }
                }
            } catch (e: Exception) {
                if (!silent) message = e.message ?: "Holatni tekshirib bo‘lmadi"
            }
        }
    }

    private fun routeStudent(status: String) {
        when (status) {
            "pending" -> studentPhase = StudentPhase.WAIT
            "approved", "active" -> startStudentExam()
            "blocked" -> studentPhase = StudentPhase.BLOCKED
            "done" -> studentPhase = StudentPhase.RESULT
            else -> studentPhase = StudentPhase.WAIT
        }
    }

    private fun startStudentExam() {
        val session = studentSession ?: return
        viewModelScope.launch {
            busy = true
            try {
                val result = withContext(Dispatchers.IO) {
                    val state = api.studentStart(session.attemptId, session.token)
                    val qs = api.studentQuestions(session.attemptId, session.token)
                    state to qs
                }
                studentState = result.first
                questions = result.second
                remainingSeconds = result.first.secondsRemaining ?: result.first.durationMinutes * 60
                studentPhase = StudentPhase.EXAM
                ExamGuard.activate()
            } catch (e: Exception) {
                message = e.message ?: "Testni boshlashda xato"
                studentPhase = StudentPhase.WAIT
            } finally {
                busy = false
            }
        }
    }

    fun saveAnswer(question: ExamQuestion, selectedIndex: Int) {
        val session = studentSession ?: return
        answers = answers + (question.attemptQuestionId to selectedIndex)
        pendingAnswers[question.attemptQuestionId] = question to selectedIndex
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    api.studentSaveAnswer(session.attemptId, session.token, question.attemptQuestionId, selectedIndex)
                }
                if (pendingAnswers[question.attemptQuestionId]?.second == selectedIndex) {
                    pendingAnswers.remove(question.attemptQuestionId)
                }
            } catch (e: Exception) {
                message = "Javob vaqtincha telefonda saqlandi. Serverga ulanish tiklanganda qayta yuboriladi."
            }
        }
    }

    private suspend fun flushPendingAnswers(session: StudentSession) {
        val snapshot = pendingAnswers.toMap()
        if (snapshot.isEmpty()) return
        withContext(Dispatchers.IO) {
            snapshot.forEach { (id, pair) ->
                api.studentSaveAnswer(session.attemptId, session.token, id, pair.second)
            }
        }
        snapshot.keys.forEach { id ->
            if (pendingAnswers[id]?.second == snapshot[id]?.second) pendingAnswers.remove(id)
        }
    }

    fun tickSecond() {
        if (studentPhase != StudentPhase.EXAM) return
        if (remainingSeconds > 0) remainingSeconds--
        if (remainingSeconds <= 0) finishStudentExam(confirm = false)
    }

    fun syncStudentTimer() {
        val session = studentSession ?: return
        viewModelScope.launch {
            try { flushPendingAnswers(session) } catch (_: Exception) { }
            checkStudentState(silent = true)
        }
    }

    fun finishStudentExam(confirm: Boolean = true) {
        val session = studentSession ?: return
        if (studentPhase != StudentPhase.EXAM) return
        viewModelScope.launch {
            busy = true
            try {
                flushPendingAnswers(session)
                val state = withContext(Dispatchers.IO) { api.studentFinish(session.attemptId, session.token) }
                studentState = state
                studentPhase = StudentPhase.RESULT
                ExamGuard.complete()
            } catch (e: Exception) {
                message = e.message ?: "Testni yakunlab bo‘lmadi"
                checkStudentState(silent = true)
            } finally {
                busy = false
            }
        }
    }

    private fun blockForViolation(reason: String) {
        val session = studentSession ?: return
        if (studentPhase != StudentPhase.EXAM) return
        studentPhase = StudentPhase.BLOCKED
        viewModelScope.launch {
            try {
                val state = withContext(Dispatchers.IO) {
                    api.studentBlock(session.attemptId, session.token, reason)
                }
                studentState = state
                if (state.status == "done") studentPhase = StudentPhase.RESULT
                else studentPhase = StudentPhase.BLOCKED
            } catch (e: Exception) {
                message = "Blok holatini serverga yozishda xato: ${e.message}"
            }
        }
    }

    fun requestRetake() {
        val session = studentSession ?: return
        viewModelScope.launch {
            busy = true
            try {
                val state = withContext(Dispatchers.IO) {
                    api.studentRequestRetake(session.attemptId, session.token)
                }
                studentState = state
                message = "Qayta topshirish so‘rovi ustozga yuborildi."
            } catch (e: Exception) {
                message = e.message ?: "Qayta topshirish so‘rovini yuborib bo‘lmadi"
            } finally {
                busy = false
            }
        }
    }

    fun leaveStudentSession() {
        if (studentPhase == StudentPhase.EXAM) return
        store.clearStudent()
        studentSession = null
        studentState = null
        questions = emptyList()
        answers = emptyMap()
        remainingSeconds = 0
        pendingAnswers.clear()
        studentPhase = StudentPhase.JOIN
        ExamGuard.complete()
        ExamGuard.clearViolation()
    }

    private fun runBusy(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                message = e.message ?: "Noma’lum xato"
                if (e is ApiException && e.statusCode == 401) {
                    teacherSession = store.loadTeacher()
                }
            } finally {
                busy = false
            }
        }
    }
}
