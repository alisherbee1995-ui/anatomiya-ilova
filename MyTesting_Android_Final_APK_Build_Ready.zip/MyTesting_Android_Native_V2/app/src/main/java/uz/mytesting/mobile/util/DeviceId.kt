package uz.mytesting.mobile.util

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest

object DeviceId {
    fun get(context: Context): String {
        val androidId = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ANDROID_ID
        ) ?: "unknown-device"
        val raw = "${context.packageName}|$androidId"
        return MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
