package uz.mytesting.mobile.util

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object ExamGuard {
    @Volatile
    var active: Boolean = false
        private set

    private val _violation = MutableStateFlow<String?>(null)
    val violation: StateFlow<String?> = _violation

    fun activate() {
        _violation.value = null
        active = true
    }

    fun complete() {
        active = false
        _violation.value = null
    }

    fun trigger(reason: String) {
        if (!active) return
        active = false
        _violation.value = reason
    }

    fun clearViolation() {
        _violation.value = null
    }
}
