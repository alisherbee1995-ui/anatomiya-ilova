package uz.mytesting.mobile.util

import org.w3c.dom.Element
import uz.mytesting.mobile.model.ImportError
import uz.mytesting.mobile.model.ImportPreview
import uz.mytesting.mobile.model.ImportQuestion
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

object QuestionFileParser {
    fun parse(input: InputStream, fileName: String): ImportPreview {
        val rows = if (fileName.lowercase().endsWith(".csv")) {
            parseCsv(input.bufferedReader(Charsets.UTF_8).readText())
        } else {
            parseXlsx(input)
        }
        return validateRows(rows, fileName)
    }

    private fun validateRows(rows: List<List<String>>, fileName: String): ImportPreview {
        if (rows.isEmpty()) return ImportPreview(emptyList(), listOf(ImportError(1, "Fayl bo‘sh")), fileName)
        val headerRowIndex = rows.indexOfFirst { it.any(String::isNotBlank) }.coerceAtLeast(0)
        val headers = rows[headerRowIndex].map(::norm)

        fun find(vararg names: String): Int {
            val normalized = names.map(::norm)
            return headers.indexOfFirst { it in normalized }
        }

        val qCol = find("Savol", "Question", "Savol matni")
        val aCol = find("A", "Variant A", "Javob A")
        val bCol = find("B", "Variant B", "Javob B")
        val cCol = find("C", "Variant C", "Javob C")
        val dCol = find("D", "Variant D", "Javob D")
        val correctCol = find("To‘g‘ri javob", "To'g'ri javob", "Togri javob", "Correct", "Correct answer")

        val missing = buildList {
            if (qCol < 0) add("Savol")
            if (aCol < 0) add("A")
            if (bCol < 0) add("B")
            if (cCol < 0) add("C")
            if (dCol < 0) add("D")
            if (correctCol < 0) add("To‘g‘ri javob")
        }
        if (missing.isNotEmpty()) {
            return ImportPreview(
                emptyList(),
                listOf(ImportError(headerRowIndex + 1, "Ustunlar topilmadi: ${missing.joinToString()}")),
                fileName
            )
        }

        val questions = mutableListOf<ImportQuestion>()
        val errors = mutableListOf<ImportError>()
        val seenQuestions = mutableSetOf<String>()
        for (r in headerRowIndex + 1 until rows.size) {
            val row = rows[r]
            fun value(i: Int) = row.getOrNull(i)?.trim().orEmpty()
            val q = value(qCol)
            val options = listOf(value(aCol), value(bCol), value(cCol), value(dCol))
            val correct = parseCorrect(value(correctCol))
            if (q.isBlank() && options.all { it.isBlank() }) continue

            val issues = mutableListOf<String>()
            if (q.isBlank()) issues += "savol matni bo‘sh"
            if (options.any { it.isBlank() }) issues += "A–D variantlardan biri bo‘sh"
            if (correct == null) issues += "to‘g‘ri javob A/B/C/D yoki 1/2/3/4 emas"
            if (options.distinct().size != 4) issues += "javob variantlari takrorlangan"
            val qKey = norm(q)
            if (qKey.isNotBlank() && !seenQuestions.add(qKey)) issues += "savol fayl ichida takrorlangan"

            if (issues.isNotEmpty()) {
                errors += ImportError(r + 1, issues.joinToString("; "))
            } else {
                questions += ImportQuestion(q, options, correct!!)
            }
        }
        return ImportPreview(questions, errors, fileName)
    }

    private fun parseCorrect(value: String): Int? = when (value.trim().uppercase()) {
        "A", "1" -> 0
        "B", "2" -> 1
        "C", "3" -> 2
        "D", "4" -> 3
        else -> null
    }

    private fun norm(value: String): String = value.trim()
        .lowercase()
        .replace('ʻ', '\'')
        .replace('ʼ', '\'')
        .replace('’', '\'')
        .replace('‘', '\'')
        .replace('`', '\'')
        .replace(Regex("\\s+"), " ")

    private fun parseCsv(text: String): List<List<String>> {
        if (text.isBlank()) return emptyList()
        val firstPhysicalLine = text.lineSequence().firstOrNull().orEmpty()
        val delimiter = listOf(',', ';', '\t').maxBy { d -> firstPhysicalLine.count { it == d } }
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> {
                    field.append('"'); i++
                }
                ch == '"' -> quoted = !quoted
                ch == delimiter && !quoted -> {
                    row += field.toString(); field.setLength(0)
                }
                (ch == '\n' || ch == '\r') && !quoted -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row += field.toString(); field.setLength(0)
                    rows += row; row = mutableListOf()
                }
                else -> field.append(ch)
            }
            i++
        }
        if (field.isNotEmpty() || row.isNotEmpty()) {
            row += field.toString(); rows += row
        }
        return rows
    }

    private fun parseXlsx(input: InputStream): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory) entries[entry.name] = zip.readBytes()
                zip.closeEntry()
            }
        }
        val factory = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { bytes ->
            val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
            val nodes = doc.getElementsByTagNameNS("*", "si")
            List(nodes.length) { index -> nodes.item(index).textContent ?: "" }
        } ?: emptyList()

        var sheetPath = "xl/worksheets/sheet1.xml"
        val workbookBytes = entries["xl/workbook.xml"]
        val relBytes = entries["xl/_rels/workbook.xml.rels"]
        if (workbookBytes != null && relBytes != null) {
            val workbook = factory.newDocumentBuilder().parse(ByteArrayInputStream(workbookBytes))
            val sheetNodes = workbook.getElementsByTagNameNS("*", "sheet")
            if (sheetNodes.length > 0) {
                val sheet = sheetNodes.item(0) as Element
                val relId = sheet.getAttributeNS(
                    "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
                    "id"
                ).ifBlank { sheet.getAttribute("r:id") }
                val rels = factory.newDocumentBuilder().parse(ByteArrayInputStream(relBytes))
                val relNodes = rels.getElementsByTagNameNS("*", "Relationship")
                for (i in 0 until relNodes.length) {
                    val rel = relNodes.item(i) as Element
                    if (rel.getAttribute("Id") == relId) {
                        val target = rel.getAttribute("Target").removePrefix("/")
                        sheetPath = if (target.startsWith("xl/")) target else "xl/$target"
                        break
                    }
                }
            }
        }

        val sheetBytes = entries[sheetPath]
            ?: entries.entries.firstOrNull { it.key.startsWith("xl/worksheets/sheet") }?.value
            ?: throw IllegalArgumentException("Excel ichida worksheet topilmadi")

        val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(sheetBytes))
        val rowNodes = doc.getElementsByTagNameNS("*", "row")
        val result = mutableListOf<List<String>>()
        for (r in 0 until rowNodes.length) {
            val rowNode = rowNodes.item(r) as Element
            val cellNodes = rowNode.getElementsByTagNameNS("*", "c")
            val values = mutableMapOf<Int, String>()
            var maxCol = -1
            for (c in 0 until cellNodes.length) {
                val cell = cellNodes.item(c) as Element
                val ref = cell.getAttribute("r")
                val col = columnIndex(ref)
                if (col < 0) continue
                val type = cell.getAttribute("t")
                val vNodes = cell.getElementsByTagNameNS("*", "v")
                val raw = if (vNodes.length > 0) vNodes.item(0).textContent.orEmpty() else ""
                val value = when (type) {
                    "s" -> raw.toIntOrNull()?.let(sharedStrings::getOrNull).orEmpty()
                    "inlineStr" -> cell.getElementsByTagNameNS("*", "is").item(0)?.textContent.orEmpty()
                    else -> raw
                }
                values[col] = value
                maxCol = maxOf(maxCol, col)
            }
            if (maxCol >= 0) result += List(maxCol + 1) { values[it].orEmpty() }
        }
        return result
    }

    private fun columnIndex(cellRef: String): Int {
        val letters = cellRef.takeWhile { it.isLetter() }.uppercase()
        if (letters.isBlank()) return -1
        var value = 0
        letters.forEach { value = value * 26 + (it - 'A' + 1) }
        return value - 1
    }
}
