package uz.mytesting.mobile.util

import uz.mytesting.mobile.model.AttemptItem
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object XlsxResultsWriter {
    fun write(attempts: List<AttemptItem>, output: OutputStream) {
        val rows = mutableListOf<List<String>>()
        rows += listOf("№", "Familiya", "Ism", "Guruh", "Yo‘nalish", "To‘g‘ri", "Jami", "Foiz", "Baho", "Holat", "Blok sababi")
        attempts.forEachIndexed { i, a ->
            rows += listOf(
                (i + 1).toString(), a.surname, a.firstName, a.groupName, a.direction,
                a.score?.toString().orEmpty(), a.total?.toString().orEmpty(),
                a.percent?.toString().orEmpty(), a.grade?.toString().orEmpty(),
                statusText(a.status), a.violationReason.orEmpty()
            )
        }

        ZipOutputStream(output.buffered()).use { zip ->
            put(zip, "[Content_Types].xml", contentTypes())
            put(zip, "_rels/.rels", packageRels())
            put(zip, "xl/workbook.xml", workbook())
            put(zip, "xl/_rels/workbook.xml.rels", workbookRels())
            put(zip, "xl/styles.xml", styles())
            put(zip, "xl/worksheets/sheet1.xml", worksheet(rows))
        }
    }

    private fun put(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun contentTypes() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

    private fun packageRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private fun workbook() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Natijalar" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""

    private fun workbookRels() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    private fun styles() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border/></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
<dxfs count="0"/>
</styleSheet>"""

    private fun worksheet(rows: List<List<String>>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        append("<sheetData>")
        rows.forEachIndexed { rowIndex, row ->
            val r = rowIndex + 1
            append("<row r=\"").append(r).append("\">")
            row.forEachIndexed { colIndex, value ->
                val ref = columnName(colIndex) + r
                val style = if (rowIndex == 0) " s=\"1\"" else ""
                append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(style).append(">")
                append("<is><t xml:space=\"preserve\">").append(xml(value)).append("</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData><autoFilter ref=\"A1:K${rows.size}\"/></worksheet>")
    }

    private fun columnName(index: Int): String {
        var n = index + 1
        val sb = StringBuilder()
        while (n > 0) {
            n--
            sb.append(('A'.code + n % 26).toChar())
            n /= 26
        }
        return sb.reverse().toString()
    }

    private fun xml(v: String) = v
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun statusText(status: String) = when (status) {
        "pending" -> "Kutilmoqda"
        "approved" -> "Ruxsat berildi"
        "active" -> "Ishlamoqda"
        "blocked" -> "Bloklandi"
        "done" -> "Tugatdi"
        else -> status
    }
}
